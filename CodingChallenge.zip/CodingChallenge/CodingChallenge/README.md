﻿<!--
*** This is the .net core 3.1 asp.net web api, which calls the api https://609aae2c0f5a13001721bb02.mockapi.io/lightfeather/managers
*** gets the supervisers list
-->
<!--
*** /api/supervisors endpoint calls the web api https://609aae2c0f5a13001721bb02.mockapi.io/lightfeather/managers and returns the supernisor list
-->

<!--
*** /api/submit-data endpoint acceepts input form data, which accesspts the form data example:
*** {"firstName":"ww","lastName":"ww","email":"ravi.vadana@gmail.com","phone":"1234567890","supervisor":"b-Elijah-Cremin"}
-->
